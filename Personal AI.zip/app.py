from flask import Flask, render_template, request, jsonify
from groq import Groq
import webbrowser
import os
import datetime
import threading
import speech_recognition as sr
import pyttsx3

app = Flask(__name__)

# ── Paste your FREE Groq API key here ────────────────────
groq_client = Groq(api_key="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")

# ── pyttsx3 is kept ONLY for wake word voice feedback ────
# The UI's hold-to-speak button uses browser TTS instead
engine = pyttsx3.init()
engine.setProperty('rate', 175)
engine.setProperty('volume', 1.0)

voices = engine.getProperty('voices')
for voice in voices:
    if "zira" in voice.name.lower() or "female" in voice.name.lower():
        engine.setProperty('voice', voice.id)
        break

def speak(text):
    """Used only for wake word audio feedback."""
    try:
        engine.say(text)
        engine.runAndWait()
    except Exception as e:
        print(f"[Voice Error] {e}")

# ── Memory ────────────────────────────────────────────────
MEMORY_FILE = "memory.txt"
conversation_history = [
    {
        "role": "system",
        "content": (
            "You are Atlas, a smart and friendly personal AI assistant. "
            "Keep your replies short, clear, and helpful. "
            "If the user asks you to open apps or search something, "
            "confirm what action is being taken in a friendly way."
        )
    }
]

def save_memory(user_msg, ai_reply):
    with open(MEMORY_FILE, "a", encoding="utf-8") as f:
        f.write(f"You: {user_msg}\nAtlas: {ai_reply}\n\n")

def ask_ai(prompt):
    """Send message to Groq and get a reply."""
    conversation_history.append({"role": "user", "content": prompt})
    try:
        response = groq_client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=conversation_history,
            max_tokens=500
        )
        reply = response.choices[0].message.content
        conversation_history.append({"role": "assistant", "content": reply})
        save_memory(prompt, reply)
        return reply
    except Exception as e:
        return f"⚠️ Groq Error: {str(e)}"

# ── Handle commands ───────────────────────────────────────
def handle_command(command):
    cmd = command.lower().strip()

    # YouTube search
    if "youtube" in cmd and ("search" in cmd or "play" in cmd or "find" in cmd):
        query = cmd
        for word in ["search youtube for", "search youtube", "play on youtube",
                     "find on youtube", "youtube search", "youtube"]:
            query = query.replace(word, "").strip()
        webbrowser.open(f"https://www.youtube.com/results?search_query={query}")
        reply = f"🎬 Searching YouTube for '{query}'"

    # Open YouTube
    elif "open youtube" in cmd:
        webbrowser.open("https://www.youtube.com")
        reply = "▶️ Opening YouTube!"

    # Google search
    elif "google" in cmd or "search for" in cmd:
        query = cmd
        for word in ["search google for", "google search for", "search for", "google", "search"]:
            query = query.replace(word, "").strip()
        webbrowser.open(f"https://www.google.com/search?q={query}")
        reply = f"🔍 Googling '{query}'"

    # Open Notepad
    elif "notepad" in cmd:
        os.startfile("notepad.exe")
        reply = "📝 Opening Notepad!"

    # Open Calculator
    elif "calculator" in cmd:
        os.startfile("calc.exe")
        reply = "🔢 Opening Calculator!"

    # Open File Explorer
    elif "file explorer" in cmd or "open files" in cmd:
        os.startfile("explorer.exe")
        reply = "📁 Opening File Explorer!"

    # Open Camera
    elif "camera" in cmd:
        os.startfile("microsoft.windows.camera:")
        reply = "📷 Opening Camera!"

    # Open Settings
    elif "open settings" in cmd:
        os.startfile("ms-settings:")
        reply = "⚙️ Opening Settings!"

    # Open Paint
    elif "open paint" in cmd:
        os.startfile("mspaint.exe")
        reply = "🎨 Opening Paint!"

    # Open Task Manager
    elif "task manager" in cmd:
        os.startfile("taskmgr.exe")
        reply = "📊 Opening Task Manager!"

    # Current time
    elif "time" in cmd and ("what" in cmd or "current" in cmd or "now" in cmd):
        now = datetime.datetime.now().strftime("%I:%M %p")
        reply = f"🕐 It's currently {now}"

    # Current date
    elif "date" in cmd and ("what" in cmd or "today" in cmd or "current" in cmd):
        today = datetime.datetime.now().strftime("%A, %B %d, %Y")
        reply = f"📅 Today is {today}"

    # Open WhatsApp Web
    elif "whatsapp" in cmd:
        webbrowser.open("https://web.whatsapp.com")
        reply = "💬 Opening WhatsApp Web!"

    # Open Gmail
    elif "gmail" in cmd or "email" in cmd:
        webbrowser.open("https://mail.google.com")
        reply = "📧 Opening Gmail!"

    # Open GitHub
    elif "github" in cmd:
        webbrowser.open("https://github.com")
        reply = "🐙 Opening GitHub!"

    # Open ChatGPT
    elif "chatgpt" in cmd:
        webbrowser.open("https://chat.openai.com")
        reply = "🤖 Opening ChatGPT!"

    # Open Spotify
    elif "spotify" in cmd:
        webbrowser.open("https://open.spotify.com")
        reply = "🎵 Opening Spotify!"

    # Open Netflix
    elif "netflix" in cmd:
        webbrowser.open("https://www.netflix.com")
        reply = "🎬 Opening Netflix!"

    # Open Twitter/X
    elif "twitter" in cmd or "open x" in cmd:
        webbrowser.open("https://twitter.com")
        reply = "🐦 Opening Twitter/X!"

    # Open Instagram
    elif "instagram" in cmd:
        webbrowser.open("https://www.instagram.com")
        reply = "📸 Opening Instagram!"

    # Shutdown PC
    elif "shutdown" in cmd or "shut down" in cmd:
        os.system("shutdown /s /t 10")
        reply = "⚠️ Shutting down your PC in 10 seconds!"

    # Restart PC
    elif "restart" in cmd:
        os.system("shutdown /r /t 10")
        reply = "🔄 Restarting your PC in 10 seconds!"

    # Lock PC
    elif "lock" in cmd and "pc" in cmd:
        os.system("rundll32.exe user32.dll,LockWorkStation")
        reply = "🔒 Locking your PC!"

    # Everything else → Groq AI
    else:
        reply = ask_ai(command)

    # NOTE: No auto-speak here — the UI handles speech via
    # the hold-to-speak Ghibli wind spirit button (browser TTS)
    return reply


# ── Wake Word Listener ────────────────────────────────────
wake_word_active = False
wake_word_status = {"listening": False, "triggered": False, "last_command": ""}

def wake_word_listener():
    recognizer = sr.Recognizer()
    recognizer.energy_threshold = 3000
    recognizer.dynamic_energy_threshold = True
    print("[Wake Word] Listening for 'Hey Atlas'...")

    while wake_word_active:
        try:
            with sr.Microphone() as source:
                recognizer.adjust_for_ambient_noise(source, duration=0.5)
                wake_word_status["listening"] = True
                audio = recognizer.listen(source, timeout=5, phrase_time_limit=4)
                wake_word_status["listening"] = False

            text = recognizer.recognize_google(audio).lower()
            print(f"[Wake Word] Heard: {text}")

            if "hey atlas" in text or "atlas" in text:
                print("[Wake Word] Triggered!")
                wake_word_status["triggered"] = True
                speak("Yes? I'm listening.")

                with sr.Microphone() as source:
                    recognizer.adjust_for_ambient_noise(source, duration=0.3)
                    print("[Wake Word] Waiting for command...")
                    cmd_audio = recognizer.listen(source, timeout=6, phrase_time_limit=8)

                command = recognizer.recognize_google(cmd_audio)
                print(f"[Wake Word] Command: {command}")
                wake_word_status["last_command"] = command
                wake_word_status["triggered"] = False

                # Wake word replies are spoken via pyttsx3 since
                # they come from outside the browser
                reply = handle_command(command)
                clean = ''.join(c for c in reply if ord(c) < 10000).strip()
                threading.Thread(target=speak, args=(clean,), daemon=True).start()

        except sr.WaitTimeoutError:
            wake_word_status["listening"] = False
        except sr.UnknownValueError:
            wake_word_status["listening"] = False
            wake_word_status["triggered"] = False
        except Exception as e:
            print(f"[Wake Word Error] {e}")
            wake_word_status["listening"] = False

wake_thread = None

# ── Flask routes ──────────────────────────────────────────
@app.route("/")
def home():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    data = request.json
    user_input = data.get("message", "").strip()
    if not user_input:
        return jsonify({"response": "Please say something!"})
    response = handle_command(user_input)
    return jsonify({"response": response})

@app.route("/wake/start", methods=["POST"])
def start_wake():
    global wake_word_active, wake_thread
    if not wake_word_active:
        wake_word_active = True
        wake_thread = threading.Thread(target=wake_word_listener, daemon=True)
        wake_thread.start()
        speak("Hey Atlas wake word is now active.")
        return jsonify({"status": "started"})
    return jsonify({"status": "already running"})

@app.route("/wake/stop", methods=["POST"])
def stop_wake():
    global wake_word_active
    wake_word_active = False
    speak("Wake word disabled.")
    return jsonify({"status": "stopped"})

@app.route("/wake/status")
def wake_status():
    return jsonify(wake_word_status)

@app.route("/voice/test", methods=["POST"])
def voice_test():
    # Browser TTS in the UI speaks this message via the hold-to-speak button
    # pyttsx3 is not used here so there's no double-speaking
    return jsonify({
        "status": "ok",
        "message": "Hello! I am Atlas, your personal AI assistant. Voice is working perfectly!"
    })

# ── Run ───────────────────────────────────────────────────
if __name__ == "__main__":
    print("=" * 55)
    print("  ATLAS AI — Ghibli UI + Groq + Hold to Speak")
    print("  Open your browser: http://127.0.0.1:5000")
    print("=" * 55)
    speak("Atlas is online and ready.")
    app.run(debug=False)
